#ifndef Calculatelib
#define Calculatelib
#include "Library.h" 
double Calculate(double amount){
    if(amount<1000){
        return amount*0.15;
    }
    else if(amount<100000){
        return amount*0.18;
    }
    else{
        return amount*0.30;
    }
}
#endif