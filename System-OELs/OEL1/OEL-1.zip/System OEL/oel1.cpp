#include<iostream>
#include<direct.h>
#include<fstream>
#include "Library.cpp"

using namespace std;

int main() 
{
    if ( mkdir("Loggedin__User")== -1) {
        cout<<" INPUT YOUR NAME :";
        string name;
         try
        {
            cin>>name;
            
        }
        catch(const char *e)
        {
            cout<<""<<e;
        }
        
        cout<<" INPUT YOUR ENROLLMENT: ";
        string enrollment;
                try
        {
            cin>>enrollment;
            
        }
        catch(const char *e)
        {
            cout<<""<<e;
        }
        ifstream data_file;
        data_file.open("Loggedin__User \\"+enrollment+".txt");
        if(data_file){
        cout<<"THIS FILE IS  EXIST";

        }
        else{
        ofstream MyFile("Loggedin__User\\newfile.txt");
        MyFile << name+"\n"+enrollment;
        MyFile.close();
        cout<<"Created file successfully";
        string line;
    ifstream ini_file{
        "Loggedin__User\\newfile.txt"
    }; 
    ofstream out_file{ "Loggedin__User\\"+enrollment+".txt" };
    if (ini_file && out_file) {
  
        while (getline(ini_file, line)) {
            out_file << line << "\n";
        }
        
    }
    else {
        printf("ERROR IN READING FILE");
    }
    ini_file.close();
    out_file.close();
    ofstream ofs;
    ofs.open("Loggedin__User\\newfile.txt", ofstream::out | ofstream::trunc);
    ofs.close();
    
    }
    }
    else {
        cout<<" INPUT YOUR NAME :";
        string name;
         try
        {
            cin>>name;
            
        }
        catch(const char *e)
        {
            cout<<""<<e;
        }
        
        cout<<" INPUT YOUR ENROLLMENT: ";
        string enrollment;
                try
        {
            cin>>enrollment;
            
        }
        catch(const char *e)
        {
            cout<<""<<e;
        }
        ifstream data_file;
        data_file.open("Loggedin__User \\"+enrollment+".txt");
        if(data_file){
        cout<<"THIS FILE IS  EXIST";

        }
        else{
        ofstream MyFile("Loggedin__User\\newfile.txt");
        MyFile << name+"\n"+enrollment;
        MyFile.close();
        cout<<"Created file successfully";
        string line;
    ifstream ini_file{
        "Loggedin__User\\newfile.txt"
    }; 
    ofstream out_file{ "Loggedin__User\\"+enrollment+".txt" };
    if (ini_file && out_file) {
  
        while (getline(ini_file, line)) {
            out_file << line << "\n";
        }
        
    }
    else {
        printf("ERROR IN READING FILE");
    }
    ini_file.close();
    out_file.close();
    ofstream ofs;
    ofs.open("Loggedin__User\\newfile.txt", ofstream::out | ofstream::trunc);
    ofs.close();
    }
    }
cout<<"\n\nINPUT AMOUNT FOR TRANSFERING :";
    double amount;
    cin>>amount;
    cout<<"TAX ON ENTERING AMOUNT IS "<<Calculate(amount);

}