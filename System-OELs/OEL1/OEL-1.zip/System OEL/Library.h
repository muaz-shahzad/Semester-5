#ifndef Library
#define Library
double Calculate(double amount);
#endif